<?php include 'header.php'; ?>
   <main>
       <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
       <h2>Image Compressor</h2>
       <p>Compress your images to reduce file size.</p>
       <input type="file" id="image-input" accept="image/*">
       <label for="quality">Quality (0-1):</label>
       <input type="number" id="quality" value="0.7" min="0" max="1" step="0.1">
       <button id="compress-button">Compress</button>
       <canvas id="output-canvas"></canvas>
       <div id="download-area"></div>
   </main>
   <script src="scripts/image-compressor.js"></script>
   <?php include 'footer.php'; ?>