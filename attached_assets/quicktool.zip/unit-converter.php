<?php include 'header.php'; ?>
<main>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
    <h2>Unit Converter</h2>
    <p>Convert between various units of measurement.</p>
    <div id="unit-converter">
        <select id="conversion-type">
            <option value="length">Length</option>
            <option value="weight">Weight</option>
            <option value="temperature">Temperature</option>
        </select>
        <input type="number" id="input-value" placeholder="Enter value">
        <select id="from-unit"></select>
        <span>to</span>
        <select id="to-unit"></select>
        <button onclick="convert()">Convert</button>
        <p id="result"></p>
    </div>
</main>
<script src="scripts/unit-converter.js"></script>
<?php include 'footer.php'; ?>