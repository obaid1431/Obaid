<?php
/**
 * pdf-merger.php
 */

// Start output buffering
ob_start();

// Check if the form is submitted
if (!isset($_POST['merge'])) {
    // Show the form page
    require_once __DIR__ . '/header.php';
    ?>
    <div class="container">
        <h2>PDF Merger</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label>Select PDF(s) to Merge:</label><br>
            <input type="file" name="pdfs[]" accept="application/pdf" multiple><br><br>
            <button type="submit" name="merge">Merge PDF(s)</button>
        </form>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    ob_end_flush();
    exit;
}

// Generate the PDF
require_once __DIR__ . '/vendor/autoload.php';
use setasign\Fpdi\TcpdfFpdi;

$pdf = new TcpdfFpdi();
$pdf->setPrintHeader(false); // Disable TCPDF header
$pdf->setPrintFooter(false); // Disable TCPDF footer

ob_end_clean(); // Discard any output from above

if (!empty($_FILES['pdfs']['name'][0])) {
    foreach ($_FILES['pdfs']['tmp_name'] as $idx => $tmpName) {
        if (is_uploaded_file($tmpName)) {
            try {
                $pageCount = $pdf->setSourceFile($tmpName);
                for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                    $pdf->AddPage();
                    $tplIdx = $pdf->importPage($pageNo);
                    $pdf->useTemplate($tplIdx, 0, 0);
                }
            } catch (Exception $e) {
                die("Error merging file: " . htmlspecialchars($_FILES['pdfs']['name'][$idx]) . 
                    "\n" . $e->getMessage());
            }
        }
    }
} else {
    die("No PDF files uploaded.");
}

$pdf->Output('merged.pdf', 'I');
exit;