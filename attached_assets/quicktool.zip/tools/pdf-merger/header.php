<!DOCTYPE html>
<html lang="en">
<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
     <!-- Google tag (gtag.js) -->
     <meta name="google-site-verification" content="Dce_UlvboReTxoef1Z2w5PsmrXsxUUPtu7EEx7idfeg" />
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZM9PXNJCB3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZM9PXNJCB3');
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'QuickToolkit'; ?></title>
    <meta name="keywords" content="online tools,text analysis tool,photo resizer,unit converter,password generator,color picker,resizer image,image editor,image compressor,zakat calculator,background remover,free tools,utility tools,web tools,productivity tools,resize image online,zakat on gold,random password,text analytics,suggest strong password">
    <meta name="description" content="QuickToolkit offers fast, free online tools for text analysis, calculations, unit conversions, and more.">
    <meta property="og:title" content="QuickToolkit - Free Online Tools">
    <meta property="og:description" content="Fast,free online tools for text analysis,calculations,unit conversions,and more.">
    <meta property="og:image" content="https://quicktoolkit.space/path/to/image.jpg"
    <meta property="og:url" content="https://quicktoolkit.space/">
    <meta property="og:type" content="website">
    <meta name="author" content="QuickToolkit Team">
    <meta name="copyright" content="Copyright © 2025 QuickToolkit">
    <meta name="robots" content="index, follow">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Merriweather:wght@400;700&display=swap" rel="stylesheet">
    <script src="scripts.js"></script>
</head>
<body>
    <header>
        <h1>Quick Toolkit</h1>
        <nav>
            <button class="menu-toggle"></button>
            <ul>
                <li><a href="index.php" class="<?php echo $current_page === 'home' ? 'active' : ''; ?>">Home</a></li>
                <li><a href="text-Analysis.php" class="<?php echo $current_page === 'text-Analysis' ? 'active' : ''; ?>">text-Analysis</a></li>
                <li><a href="zakat calculator.php" class="<?php echo $current_page === 'zakat calculator' ? 'active' : ''; ?>">zakat Calculator</a></li>
                <li><a href="unit-converter.php" class="<?php echo $current_page === 'unit-converter' ? 'active' : ''; ?>">Unit Converter</a></li>
                <li><a href="password-generator.php" class="<?php echo $current_page === 'password-generator' ? 'active' : ''; ?>">Password Generator</a></li>
                <li><a href="color-picker.php" class="<?php echo $current_page === 'color-picker' ? 'active' : ''; ?>">Color Picker</a></li>
                <li><a href="image-compressor.php" class="<?php echo $current_page === 'image-compressor' ? 'active' : ''; ?>">Image Compressor</a></li>
            </ul>
        </nav>
    </header>
    <main>