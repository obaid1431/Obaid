<!DOCTYPE html>
<html lang="en">
    <?php include 'header.php'; ?>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Zakat Calculator</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
    }
    .container {
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      margin: 0 auto;
      text-align: center;
    }
    h2 {
      color: #007bff;
    }
    .input-group {
      margin-bottom: 15px;
      text-align: left;
    }
    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    input, select {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    button {
      background-color: #007bff;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 10px;
    }
    button:hover {
      background-color: #0056b3;
    }
    #result {
      margin-top: 20px;
      font-size: 18px;
      font-weight: bold;
      color: #333;
    }
    .note {
      font-style: italic;
      color: #555;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Zakat Calculator</h2>
    <p class="note">
      Enter the weight of your gold/silver and their rates per gram (as per your country's current rates).
    </p>

    <!-- Currency Selection -->
    <div class="input-group">
      <label for="currency">Select Currency:</label>
      <select id="currency">
        <option value="USD">USD</option>
        <option value="INR">INR</option>
        <option value="PKR">PKR</option>
        <option value="SAR">SAR</option>
        <option value="GBP">GBP</option>
        <option value="AED">AED</option>
        <option value="CAD">CAD</option>
        <option value="SGD">SGD</option>
        <option value="BHD">BHD</option>
        <option value="QAR">QAR</option>
        <option value="OMR">OMR</option>
      </select>
    </div>

    <!-- Gold Inputs -->
    <div class="input-group">
      <label>Gold Weight:</label>
      <input type="number" id="gold-weight" placeholder="Enter gold weight" min="0" />
      <select id="gold-unit">
        <option value="grams">Grams</option>
        <option value="tola">Tola</option>
        <option value="milligrams">Milligrams</option>
      </select>
    </div>
    <div class="input-group">
      <label>Gold Price per Gram (as per your country):</label>
      <input type="number" id="gold-rate" placeholder="e.g. 65" min="0" />
    </div>

    <!-- Silver Inputs -->
    <div class="input-group">
      <label>Silver Weight:</label>
      <input type="number" id="silver-weight" placeholder="Enter silver weight" min="0" />
      <select id="silver-unit">
        <option value="grams">Grams</option>
        <option value="tola">Tola</option>
        <option value="milligrams">Milligrams</option>
      </select>
    </div>
    <div class="input-group">
      <label>Silver Price per Gram (as per your country):</label>
      <input type="number" id="silver-rate" placeholder="e.g. 0.8" min="0" />
    </div>

    <!-- Cash -->
    <div class="input-group">
      <label>Cash Amount:</label>
      <input type="number" id="cash" placeholder="Enter cash amount" min="0" />
    </div>

    <button onclick="calculateZakat()">Calculate Zakat</button>

    <div id="result"></div>
  </div>

  <script>
    // Helper function to convert any weight to grams
    function convertToGrams(weight, unit) {
      if (unit === 'tola') {
        return weight * 11.664;
      } else if (unit === 'milligrams') {
        return weight / 1000;
      } else {
        // Default is grams
        return weight;
      }
    }

    function calculateZakat() {
      // Get input values
      const currency = document.getElementById('currency').value;
      
      const goldWeight = parseFloat(document.getElementById('gold-weight').value) || 0;
      const goldUnit = document.getElementById('gold-unit').value;
      const goldRate = parseFloat(document.getElementById('gold-rate').value) || 0;
      
      const silverWeight = parseFloat(document.getElementById('silver-weight').value) || 0;
      const silverUnit = document.getElementById('silver-unit').value;
      const silverRate = parseFloat(document.getElementById('silver-rate').value) || 0;
      
      const cash = parseFloat(document.getElementById('cash').value) || 0;
      
      // Convert gold and silver to grams
      const goldInGrams = convertToGrams(goldWeight, goldUnit);
      const silverInGrams = convertToGrams(silverWeight, silverUnit);
      
      // Calculate gold and silver value
      const goldValue = goldInGrams * goldRate;
      const silverValue = silverInGrams * silverRate;
      
      // Calculate total wealth and Zakat (2.5%)
      const totalWealth = goldValue + silverValue + cash;
      const zakatAmount = totalWealth * 0.025;

      // Display results
      const resultDiv = document.getElementById('result');
      
      if (totalWealth > 0) {
        resultDiv.innerHTML = `PLEASE RECONFIRM IT WITH YOUR LOCAL MUFTI,ALEEM OR ULMA E KARAM AS THIS ARE JUST FOR INFORMATION PURPOSE ONLY,ONE TOLA=11.6638038
          <p>Total Wealth: ${totalWealth.toFixed(2)} ${currency}</p>
          <p>Zakat Amount (2.5%): ${zakatAmount.toFixed(2)} ${currency}</p>
        `;
      } else {
        resultDiv.innerHTML = `<p style="color:red">Please enter valid values to calculate Zakat.</p>`;
      }
    }
  </script>
</body>
<?php include 'footer.php'; ?>
</html>
