<?php include 'header.php'; ?>

<?php
// API key and request tracking
$api_key = 'your_api_key_here'; // Replace with your MeaningCloud API key
$request_file = 'request_count.txt'; // File to store request count
$max_requests = 40000; // Monthly limit

// Reset request count at the start of each month
$month = date('Ym'); // Format: YYYYMM (e.g., 202410 for October 2024)
if (!file_exists($request_file) || file_get_contents($request_file) < $month) {
    file_put_contents($request_file, $month . ':0');
}

// Get current request count
list($stored_month, $request_count) = explode(':', file_get_contents($request_file));
if ($stored_month != $month) {
    $request_count = 0; // Reset if it's a new month
} else {
    $request_count = (int)$request_count; // Convert to integer
}

// Summarize logic
$summary = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($request_count >= $max_requests) {
        $error = 'Monthly API request limit reached. Please try again next month.';
    } else {
        $text = $_POST['text'];
        if (strlen($text) > 8192) {
            $error = 'Text exceeds the maximum limit of 8192 characters.';
        } else if (empty($text)) {
            $error = 'Please enter some text to summarize.';
        } else {
            $url = 'https://api.meaningcloud.com/summarization-1.0';
            $data = array(
                'key' => $api_key,
                'txt' => $text,
                'sentences' => '5' // Number of sentences in summary, adjustable
            );
            $options = array(
                'http' => array(
                    'method' => 'POST',
                    'header' => 'Content-type: application/x-www-form-urlencoded',
                    'content' => http_build_query($data)
                )
            );
            $context = stream_context_create($options);
            $response = file_get_contents($url, false, $context);
            $response_data = json_decode($response);
            if ($response_data->status->code === '0') {
                $summary = $response_data->summary;
                // Increment request count after successful API call
                $request_count++;
                file_put_contents($request_file, $month . ':' . $request_count);
            } else {
                $error = 'Error: ' . $response_data->status->msg;
            }
        }
    }
}
?>

<main>
    <div class="tool-banner">
        <h2>AI Text Summarizer</h2>
        <p>Enter your text below to generate a concise summary using AI.</p>
    </div>
    <form method="post">
        <textarea name="text" rows="10" cols="50" placeholder="Paste your text here..." required></textarea>
        <p>Maximum 8192 characters.</p>
        <button type="submit">Summarize</button>
    </form>
    <?php if (!empty($summary)) { ?>
        <div id="summary">
            <h3>Summary:</h3>
            <p><?php echo $summary; ?></p>
        </div>
    <?php } elseif (!empty($error)) { ?>
        <div id="error" style="color: red;">
            <p><?php echo $error; ?></p>
        </div>
    <?php } ?>
</main>

<?php include 'footer.php'; ?>