<?php include 'header.php'; ?>
<main>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
     <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZM9PXNJCB3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZM9PXNJCB3');
</script>
    <h2>Welcome to QuickToolkit</h2>
    <p>Your fast and handy online toolkit.</p>
    <div class="tool-grid">
        <div class="tool-card">
            <i class="fas fa-file-alt"></i>
            <h3>Text Analyzer</h3>
            <p>Analyze your text for word count, character count, and more.</p>
            <!-- Updated link to tools/text-analyzer.php -->
            <a href="Text-Analysis.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-brain"></i>
            <h3>AI Text Summarizer</h3>
            <p>Summarize long texts into concise summaries using AI.</p>
            <a href="ai-text-summarizer.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>image-resizer</h3>
            <p>resize your image with orignal quality.</p>
            <a href="image-resizer.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>pdf-merger</h3>
            <p>A tool to merge the PDFs.</p>
            <a href="tools/pdf-merger/pdf-merger.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-exchange-alt"></i>
            <h3>Unit Converter</h3>
            <p>Convert between units like length, weight, temperature, and data sizes quickly and accurately.</p>
            <a href="unit-converter.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-key"></i>
            <h3>Password Generator</h3>
            <p>Generate secure, random passwords.</p>
            <a href="password-generator.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>Color Picker</h3>
            <p>Pick colors and view their HEX, RGB, and HSL values.</p>
            <a href="color-picker.php">Go to Tool</a>
        </div>
        <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>image-compressor</h3>
            <p>compressed the image with orignal quality.</p>
            <a href="image-compressor.php">Go to Tool</a>
        </div>  
        <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>zakat calculator</h3>
            <p>calculate your zakat calculate your gold,assests.</p>
            <a href="zakat calculator.php">Go to Tool</a>
         </div>
         <div class="tool-card">
            <i class="fas fa-palette"></i>
            <h3>Background Remover</h3>
            <p>Remove unwanted backgroun or things not needed.</p>
            <a href="background-remover.php">Go to Tool</a>
         </div>
    </div>
</main>
<?php include 'footer.php'; ?>
</script>
