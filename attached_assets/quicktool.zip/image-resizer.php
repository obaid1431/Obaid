<?php include 'header.php'; ?>
<main>
  <h2>Advanced Image Resizer</h2>
  <p>Resize, rotate, and crop your images.</p>

  <!-- File input for multiple images -->
  <input type="file" id="file-input" accept="image/*" multiple /><br><br>

  <!-- Resize options -->
  <label for="width-input">Width:</label>
  <input type="number" id="width-input" placeholder="Width">
  <label for="height-input">Height:</label>
  <input type="number" id="height-input" placeholder="Height">
  <button id="resize-button">Resize</button><br><br>

  <!-- Rotation buttons -->
  <button id="rotate-left">Rotate Left</button>
  <button id="rotate-right">Rotate Right</button><br><br>

  <!-- Crop options -->
  <h3>Crop Options (Center Crop)</h3>
  <label for="crop-width">Crop Width:</label>
  <input type="number" id="crop-width" placeholder="Crop Width">
  <label for="crop-height">Crop Height:</label>
  <input type="number" id="crop-height" placeholder="Crop Height">
  <button id="crop-button">Crop</button><br><br>

  <!-- Canvas for displaying the edited image -->
  <canvas id="canvas" style="border: 1px solid #ccc;"></canvas><br><br>

  <!-- Download area -->
  <div id="download-area"></div>

  <!-- Thumbnails for multiple images -->
  <h3>Image Thumbnails</h3>
  <div id="thumbnails" style="display: flex; flex-wrap: wrap; gap: 10px;"></div>
</main>
 <script src="scripts/image-resizer.js"></script>
<?php include 'footer.php'; ?>
