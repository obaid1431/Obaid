<!DOCTYPE html>
<html lang="en">
<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
     <!-- Google tag (gtag.js) -->
     <meta name="google-site-verification" content="Dce_UlvboReTxoef1Z2w5PsmrXsxUUPtu7EEx7idfeg" />
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZM9PXNJCB3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZM9PXNJCB3');
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick Toolkit - Free Online Tools for Text, PDF, Image, and More</title>
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="manifest" href="manifest.json">
    <link rel="canonical" href="https://quicktoolkit.space/"/>
    <meta name="robots" content="index, follow">
    <meta name="googlebot" content="index, follow, max-snippet:-1, max-image-size:-1, max-video-size:-1">
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-size:-1, max-video-size:-1">
    <meta name="description" content="Discover a comprehensive suite of free online tools at Quick Toolkit. From text analysis and PDF merging to image editing and more, find everything you need to simplify your tasks.">
    <meta name="keywords" content="online tools, text analyzer, calculator, unit converter, password generator, color picker, image resizer, PDF merger, language translator, time zone converter, currency converter, QR code generator, email validator, password strength checker">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Quick Toolkit">
    <meta property="og:url" content="https://quicktoolkit.space/"/>
    <meta property="og:description" content="Discover a comprehensive suite of free online tools at Quick Toolkit. From text analysis and PDF merging to image editing and more, find everything you need to simplify your tasks.">
    <meta property="og:image" content="https://quicktoolkit.space/images/og-image.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@quicktoolkit">
    <meta name="twitter:creater" content="@quicktoolkit">
    <meta name="twitter:url" content="https://quicktoolkit.space/"/>
    <meta name="twitter:description" content="Discover a comprehensive suite of free online tools at Quick Toolkit. From text analysis and PDF merging to image editing and more, find everything you need to simplify your tasks.">
    <meta name="twitter:image" content="https://quicktoolkit.space/images/og-image.jpg">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://www.google.com">
    <link rel="preconnect" href="https://www.googletagmanager.com">
    <link rel="preconnect" href="https://www.googleadservices.com">
    <link rel="preconnect" href="https://www.google.com/recaptchav3">
    <link rel="preconnect" href="https://www.gstatic.com/recaptchav3">
    <script src="https://www.google.com/recaptchav3.js?render=6LdVtScuAAAAAJpF252Xy9eZlD4zHv5dZx2sYzWg"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-XXXXXXXXXX');
    </script>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 0;
            background-color: F5F5F5;
        }
        header {
            background-color: #A1DBFF;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: less-space between;
            align-items: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        header nav {
            display: flex;
            align-items: center;
        }
        header nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-size: 16px;
        }
        header nav a.active {
            font-weight: bold;
        }
        main {
            padding: 20px;
        }
        .tool-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .tool-card {
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 4px 0 #ddd;
            padding: 20px;
            text-align: center;
        }
        .tool-card i {
            font-size: 48px;
            color: #007bff;
            margin-bottom: 10px;
        }
        .tool-card h3 {
            font-size: 20px;
            margin: 0;
            margin-bottom: 10px;
        }
        .tool-card p {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        .tool-card a {
            display: block;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        .tool-card a i {
            margin-right: 5px;
        }
        footer {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            text-align: center;
            font-size: 12px;
        }
    </style>
</head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'QuickToolkit'; ?></title>
    <meta name="keywords" content="online tools,text analysis tool,photo resizer,unit converter,password generator,color picker,resizer image,image editor,image compressor,zakat calculator,background remover,free tools,utility tools,web tools,productivity tools,resize image online,zakat on gold,random password,text analytics,suggest strong password">
    <meta name="description" content="QuickToolkit offers fast, free online tools for text analysis, calculations, unit conversions, and more.">
    <meta property="og:title" content="QuickToolkit - Free Online Tools">
    <meta property="og:description" content="Fast,free online tools for text analysis,calculations,unit conversions,and more.">
    <meta property="og:image" content="https://quicktoolkit.space/path/to/image.jpg"
    <meta property="og:url" content="https://quicktoolkit.space/">
    <meta property="og:type" content="website">
    <meta name="author" content="QuickToolkit Team">
    <meta name="copyright" content="Copyright © 2025 QuickToolkit">
    <meta name="robots" content="index, follow">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Merriweather:wght@400;700&display=swap" rel="stylesheet">
    <script src="scripts.js"></script>
</head>
<body>
    <header>
        <h1> Quick Toolkit </h1>
        <nav>
            <ul>
                <li><a href="index.php" class="<?php echo $current_page === 'home' ? 'active' : ''; ?>">Home</a></li>
                <li><a href="Text-Analysis.php" class="<?php echo $current_page === 'text-Analysis' ? 'active' : ''; ?>">Text-Analysis</a></li>
                <li><a href="tools/pdf-merger/pdf-merger.php" class="<?php echo $current_page === 'pdf-merger' ? 'active' : ''; ?>">Pdf merger</a></li>
                <li><a href="zakat calculator.php" class="<?php echo $current_page === 'zakat calculator' ? 'active' : ''; ?>">zakat Calculator</a></li>
                <li><a href="unit-converter.php" class="<?php echo $current_page === 'unit-converter' ? 'active' : ''; ?>">Unit Converter</a></li>
                <li><a href="password-generator.php" class="<?php echo $current_page === 'password-generator' ? 'active' : ''; ?>">Password Generator</a></li>
                <li><a href="color-picker.php" class="<?php echo $current_page === 'color-picker' ? 'active' : ''; ?>">Color Picker</a></li>
                <li><a href="image-compressor.php" class="<?php echo $current_page === 'image-compressor' ? 'active' : ''; ?>">Image Compressor</a></li>
            </ul>
        </nav>
    </header>
    <main>