<?php include 'header.php'; ?>
<main>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
    <h2>Password Generator</h2>
    <p>Generate secure, random passwords.</p>
    <div id="password-generator">
        <label for="length">Length:</label>
        <input type="number" id="length" min="1" value="12">
        <label><input type="checkbox" id="include-numbers" checked> Include Numbers</label>
        <label><input type="checkbox" id="include-symbols" checked> Include Symbols</label>
        <label><input type="checkbox" id="include-uppercase" checked> Include Uppercase</label>
        <button onclick="generatePassword()">Generate</button>
        <p id="password"></p>
    </div>
</main>
<script src="scripts/password-generator.js"></script>
<?php include 'footer.php'; ?>