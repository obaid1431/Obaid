<div>
    <label for="amount">Amount:</label>
    <input type="number" id="amount" placeholder="Enter amount">
</div>
<div>
    <label for="fromCurrency">From:</label>
    <select id="fromCurrency">
        <option value="USD">USD</option>
        <option value="EUR">EUR</option>
        <!-- Add more currencies -->
    </select>
</div>
<div>
    <label for="toCurrency">To:</label>
    <select id="toCurrency">
        <option value="EUR">EUR</option>
        <option value="USD">USD</option>
        <!-- Add more currencies -->
    </select>
</div>
<button onclick="convertCurrency()">Convert</button>
<p id="conversionResult"></p>