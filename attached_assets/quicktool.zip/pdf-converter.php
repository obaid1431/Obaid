<?php include 'header.php'; ?>
   <main>
       <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
       <h2>PDF Converter</h2>
       <p>Convert your files to and from PDF format.</p>
       <form action="process-pdf-conversion.php" method="post" enctype="multipart/form-data">
           <label for="file-input">Select File:</label>
           <input type="file" id="file-input" name="uploadedFile">
           <label for="target-format">Convert To:</label>
           <select id="target-format" name="targetFormat">
               <option value="pdf">PDF</option>
               <option value="docx">DOCX</option>
               <option value="jpg">JPG</option>
               </select>
           <button type="submit">Convert</button>
       </form>
       <div id="results">
           </div>
   </main>
   <?php include 'footer.php'; ?>