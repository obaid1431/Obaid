<?php include 'header.php'; ?>

<div class="tool-section">
    <h2>Background Remover</h2>
    <input type="file" id="background-remover-input" accept="image/*">
    <button onclick="removeBackground()">Remove Background</button>
    <div id="background-remover-result"></div>
</div>
</main>
<script src="scripts/background-remover.js"></script>
<?php include 'footer.php'; ?>