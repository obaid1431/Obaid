    </main>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> QuickToolkit. All rights reserved.</p>
    </footer>
</body>
</html>