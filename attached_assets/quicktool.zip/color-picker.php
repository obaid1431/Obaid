<?php include 'header.php'; ?>
<main>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209"
     crossorigin="anonymous"></script>
    <h2>Color Picker</h2>
    <p>Pick a color and view its HEX, RGB, and HSL values.</p>
    <div id="color-picker">
        <div class="color-display" id="color-display"></div>
        <input type="color" id="color-input">
        <div class="color-values">
            <p>HEX: <span id="hex" onclick="copyToClipboard('hex')"></span></p>
            <p>RGB: <span id="rgb" onclick="copyToClipboard('rgb')"></span></p>
            <p>HSL: <span id="hsl" onclick="copyToClipboard('hsl')"></span></p>
        </div>
        <div class="preview">
            <h3>Preview</h3>
            <button id="preview-button">Button</button>
            <p id="preview-text">Sample Text</p>
        </div>
    </div>
</main>
<script src="scripts/color-picker.js"></script>
<?php include 'footer.php'; ?>