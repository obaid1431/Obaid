<?php include 'header.php'; ?>
   <main>
       <h2>Basic Image Editor</h2>
       <p>Perform basic edits on your images.</p>
       <input type="file" id="image-input" acceptfor image files.">
<div id="edit-options">
<button id="rotate-left">Rotate Left</button>
<button id="rotate-right">Rotate Right</button>
<label for="crop-width">Crop Width:</label>
<input type="number" id="crop-width" placeholder="Width">
<label for="crop-height">Crop Height:</label>
<input type="number" id="crop-height" placeholder="Height">
<button id="crop-button">Crop</button>
</div>
<canvas id="canvas"></canvas>
<div id="download-area"></div>
</main>
<script src="scripts/image-editor.js"></script>
<?php include 'footer.php'; ?>

