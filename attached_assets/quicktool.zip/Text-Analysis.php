<?php include 'header.php'; ?>
<main>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5793515668847209" crossorigin="anonymous"></script>
    <h2>Text Analysis</h2>
    <p>Enter your text below to analyze it.</p>
    <textarea id="text-input" rows="10" placeholder="Type or paste your text here..."></textarea>
    <div id="results">
        <p>Word Count: <span id="word-count">0</span></p>
        <p>Character Count: <span id="char-count">0</span></p>
        <p>Sentence Count: <span id="sentence-count">0</span></p>
        <p>Paragraph Count: <span id="paragraph-count">0</span></p>
        <p>Keyword Density: <span id="keyword-density"></span></p>
        <p>Readability Score: <span id="readability-score"></span></p>
        <p>Sentiment: <span id="sentiment"></span></p>
    </div>
</main>
<script src="scripts/Text-Analysis.js"></script>