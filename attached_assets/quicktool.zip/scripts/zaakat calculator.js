 // Helper function to convert any weight to grams
    function convertToGrams(weight, unit) {
      if (unit === 'tola') {
        return weight * 11.664;
      } else if (unit === 'milligrams') {
        return weight / 1000;
      } else {
        // Default is grams
        return weight;
      }
    }

    function calculateZakat() {
      // Get input values
      const currency = document.getElementById('currency').value;
      
      const goldWeight = parseFloat(document.getElementById('gold-weight').value) || 0;
      const goldUnit = document.getElementById('gold-unit').value;
      const goldRate = parseFloat(document.getElementById('gold-rate').value) || 0;
      
      const silverWeight = parseFloat(document.getElementById('silver-weight').value) || 0;
      const silverUnit = document.getElementById('silver-unit').value;
      const silverRate = parseFloat(document.getElementById('silver-rate').value) || 0;
      
      const cash = parseFloat(document.getElementById('cash').value) || 0;
      
      // Convert gold and silver to grams
      const goldInGrams = convertToGrams(goldWeight, goldUnit);
      const silverInGrams = convertToGrams(silverWeight, silverUnit);
      
      // Calculate gold and silver value
      const goldValue = goldInGrams * goldRate;
      const silverValue = silverInGrams * silverRate;
      
      // Calculate total wealth and Zakat (2.5%)
      const totalWealth = goldValue + silverValue + cash;
      const zakatAmount = totalWealth * 0.025;

      // Display results
      const resultDiv = document.getElementById('result');
      
      if (totalWealth > 0) {
        resultDiv.innerHTML = `
          <p>Total Wealth: ${totalWealth.toFixed(2)} ${currency}</p>
          <p>Zakat Amount (2.5%): ${zakatAmount.toFixed(2)} ${currency}</p>
        `;
      } else {
        resultDiv.innerHTML = `<p style="color:red">Please enter valid values to calculate Zakat.</p>`;
      }
    }