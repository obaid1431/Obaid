document.addEventListener('DOMContentLoaded', function() {
       const imageInput = document.getElementById('image-input');
       const qualityInput = document.getElementById('quality');
       const compressButton = document.getElementById('compress-button');
       const outputCanvas = document.getElementById('output-canvas');
       const downloadArea = document.getElementById('download-area');
   
       compressButton.addEventListener('click', function() {
           const file = imageInput.files[0];
           if (!file) {
               alert('Please select an image.');
               return;
           }
   
           const reader = new FileReader();
           reader.onload = function(e) {
               const img = new Image();
               img.onload = function() {
                   outputCanvas.width = img.width;
                   outputCanvas.height = img.height;
                   const ctx = outputCanvas.getContext('2d');
                   ctx.drawImage(img, 0, 0);
   
                   const quality = parseFloat(qualityInput.value);
                   const compressedImage = outputCanvas.toDataURL('image/jpeg', quality); // Quality 0-1
   
                   // Create a download link
                   const downloadLink = document.createElement('a');
                   downloadLink.href = compressedImage;
                   downloadLink.download = 'compressed-image.jpg';
                   downloadArea.innerHTML = '';
                   downloadArea.appendChild(downloadLink);
                   downloadLink.textContent = 'Download Compressed Image';
               };
               img.src = e.target.result;
           };
           reader.readAsDataURL(file);
       });
   });