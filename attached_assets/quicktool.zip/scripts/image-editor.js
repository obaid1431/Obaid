 document.addEventListener('DOMContentLoaded', function() {
       const imageInput = document.getElementById('image-input');
       const canvas = document.getElementById('canvas');
       const ctx = canvas.getContext('2d');
       const rotateLeftButton = document.getElementById('rotate-left');
       const rotateRightButton = document.getElementById('rotate-right');
       const cropWidthInput = document.getElementById('crop-width');
       const cropHeightInput = document.getElementById('crop-height');
       const cropButton = document.getElementById('crop-button');
       const downloadArea = document.getElementById('download-area');
   
       let img;
       let rotation = 0;
   
       imageInput.addEventListener('change', function(e) {
           const file = e.target.files[0];
           if (!file) return;
   
           const reader = new FileReader();
           reader.onload = function(event) {
               img = new Image();
               img.onload = function() {
                   canvas.width = img.width;
                   canvas.height = img.height;
                   drawImage();
               };
               img.src = event.target.result;
           };
           reader.readAsDataURL(file);
       });
   
       function drawImage() {
           ctx.clearRect(0, 0, canvas.width, canvas.height);
           ctx.save();
           ctx.translate(canvas.width / 2, canvas.height / 2);
           ctx.rotate(rotation * Math.PI / 180);
           ctx.drawImage(img, -img.width / 2, -img.height / 2);
           ctx.restore();
       }
   
       rotateLeftButton.addEventListener('click', function() {
           rotation -= 90;
           drawImage();
       });
   
       rotateRightButton.addEventListener('click', function() {
           rotation += 90;
           drawImage();
       });
   
       cropButton.addEventListener('click', function() {
           const cropWidth = cropWidthInput.value ? parseInt(cropWidthInput.value) : canvas.width;
           const cropHeight = cropHeightInput.value ? parseInt(cropHeightInput.value) : canvas.height;
   
           const tempCanvas = document.createElement('canvas');
           tempCanvas.width = cropWidth;
           tempCanvas.height = cropHeight;
           const tempCtx = tempCanvas.getContext('2d');
   
           // Simple center crop (you can modify this)
           const startX = (canvas.width - cropWidth) / 2;
           const startY = (canvas.height - cropHeight) / 2;
   
           tempCtx.drawImage(canvas, startX, startY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
   
           canvas.width = cropWidth;
           canvas.height = cropHeight;
           ctx.drawImage(tempCanvas, 0, 0);
       });
   
       // Add download functionality after any edit
       canvas.addEventListener('click', function() {
           if (canvas.toDataURL()) {
               const downloadLink = document.createElement('a');
               downloadLink.href = canvas.toDataURL('image/jpeg');
               downloadLink.download = 'edited-image.jpg';
               downloadArea.innerHTML = '';
               downloadArea.appendChild(downloadLink);
               downloadLink.textContent = 'Download Edited Image';
           }
       });
   });