document.addEventListener('DOMContentLoaded', function() {
    const textInput = document.getElementById('text-input');
    const wordCount = document.getElementById('word-count');
    const charCount = document.getElementById('char-count');
    const sentenceCount = document.getElementById('sentence-count');
    const paragraphCount = document.getElementById('paragraph-count');
    const keywordDensity = document.getElementById('keyword-density');
    const readabilityScore = document.getElementById('readability-score');
    const sentiment = document.getElementById('sentiment');

    textInput.addEventListener('input', function() {
        const text = textInput.value;
        // Basic Counts
        const words = text.trim().split(/\s+/).filter(word => word.length > 0);
        wordCount.textContent = words.length;
        charCount.textContent = text.length;
        const sentences = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0);
        sentenceCount.textContent = sentences.length;
        const paragraphs = text.split(/\n+/).filter(paragraph => paragraph.trim().length > 0);
        paragraphCount.textContent = paragraphs.length;

        // Keyword Density (top 5 keywords)
        const keywordCounts = {};
        words.forEach(word => {
            word = word.toLowerCase();
            keywordCounts[word] = (keywordCounts[word] || 0) + 1;
        });
        const sortedKeywords = Object.entries(keywordCounts).sort((a, b) => b[1] - a[1]);
        let topKeywords = sortedKeywords.slice(0, 5)
                            .map(item => `${item[0]} (${((item[1] / words.length) * 100).toFixed(2)}%)`)
                            .join(', ');
        keywordDensity.textContent = topKeywords;

        // Readability Score (Flesch-Kincaid - simplified)
        const avgSentenceLength = words.length / sentences.length;
        const avgSyllablesPerWord = calculateAvgSyllables(words);
        const fleschKincaid = 206.835 - 1.015 * avgSentenceLength - 84.6 * avgSyllablesPerWord;
        readabilityScore.textContent = fleschKincaid.toFixed(2);

        // Sentiment Analysis (very basic)
        const positiveWords = ['good', 'great', 'excellent', 'happy'];
        const negativeWords = ['bad', 'terrible', 'sad', 'angry'];
        let positiveCount = 0;
        let negativeCount = 0;
        words.forEach(word => {
            word = word.toLowerCase();
            if (positiveWords.includes(word)) positiveCount++;
            if (negativeWords.includes(word)) negativeCount++;
        });
        let overallSentiment = 'Neutral';
        if (positiveCount > negativeCount) overallSentiment = 'Positive';
        if (negativeCount > positiveCount) overallSentiment = 'Negative';
        sentiment.textContent = overallSentiment;
    });

    // Helper function for calculating average syllables per word
    function calculateAvgSyllables(words) {
        let totalSyllables = 0;
        words.forEach(word => {
            word = word.toLowerCase();
            // Use an empty array fallback if no vowels are found
            let syllables = (word.match(/[aeiouy]+/g) || []).length;
            syllables = Math.max(1, syllables); // Ensure at least 1 syllable
            totalSyllables += syllables;
        });
        return totalSyllables / words.length;
    }
})