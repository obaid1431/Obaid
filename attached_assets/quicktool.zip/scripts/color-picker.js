document.addEventListener('DOMContentLoaded', function() {
    const colorInput = document.getElementById('color-input');
    const colorDisplay = document.getElementById('color-display');
    const hex = document.getElementById('hex');
    const rgb = document.getElementById('rgb');
    const hsl = document.getElementById('hsl');
    const previewButton = document.getElementById('preview-button');
    const previewText = document.getElementById('preview-text');
    
    colorInput.addEventListener('input', function() {
        const color = colorInput.value;
        colorDisplay.style.backgroundColor = color;
        hex.textContent = color;
        rgb.textContent = hexToRgb(color);
        hsl.textContent = hexToHsl(color);
        previewButton.style.backgroundColor = color;
        previewText.style.color = color;
    });
    
    function hexToRgb(hex) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `${r}, ${g}, ${b}`;
    }
    
    function hexToHsl(hex) {
        let r = parseInt(hex.slice(1, 3), 16) / 255;
        let g = parseInt(hex.slice(3, 5), 16) / 255;
        let b = parseInt(hex.slice(5, 7), 16) / 255;
        
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;
        
        if (max === min) {
            h = s = 0; // achromatic
        } else {
            let d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
        
        h = Math.round(h * 360);
        s = Math.round(s * 100);
        l = Math.round(l * 100);
        return `${h}°, ${s}%, ${l}%`;
    }
});

function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    const text = element.textContent;
    navigator.clipboard.writeText(text).then(() => {
        alert('Copied to clipboard: ' + text);
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}