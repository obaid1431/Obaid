async function removeBackground() {
    const input = document.getElementById('background-remover-input');
    const resultDiv = document.getElementById('background-remover-result');
    resultDiv.innerHTML = 'Processing...';

    if (!input.files[0]) {
        resultDiv.innerHTML = 'Please select an image.';
        return;
    }

    const { pipeline } = window.transformers;
    const model = await pipeline('image-segmentation', 'Xenova/detr-resnet-50-panoptic');
    const image = await loadImage(input.files[0]);

    const outputs = await model(image);
    const mask = outputs[0].mask;

    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(image, 0, 0);
    ctx.globalCompositeOperation = 'destination-in';
    ctx.drawImage(mask, 0, 0);

    resultDiv.innerHTML = '';
    resultDiv.appendChild(canvas);
}

function loadImage(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}