document.addEventListener('DOMContentLoaded', function() {
  // ======= DOM ELEMENTS =======
  const fileInput = document.getElementById('file-input');
  const widthInput = document.getElementById('width-input');
  const heightInput = document.getElementById('height-input');
  const resizeButton = document.getElementById('resize-button');
  const rotateLeftButton = document.getElementById('rotate-left');
  const rotateRightButton = document.getElementById('rotate-right');
  const cropWidthInput = document.getElementById('crop-width');
  const cropHeightInput = document.getElementById('crop-height');
  const cropButton = document.getElementById('crop-button');
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const downloadArea = document.getElementById('download-area');
  const thumbnailsDiv = document.getElementById('thumbnails');

  // ======= GLOBAL VARIABLES =======
  // Array to hold each image along with its rotation value.
  let images = []; // Each entry: { img: Image, rotation: number }
  let currentIndex = 0;

  // ======= DRAW FUNCTION =======
  function drawImage() {
    if (images.length === 0) return;
    const current = images[currentIndex];
    const img = current.img;
    const rotation = current.rotation;

    // Get target dimensions from inputs; if not provided, use the image’s natural size.
    const targetWidth = parseInt(widthInput.value, 10) || img.width;
    const targetHeight = parseInt(heightInput.value, 10) || img.height;

    // Set canvas dimensions
    canvas.width = targetWidth;
    canvas.height = targetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    // Translate to canvas center and apply rotation
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rotation * Math.PI / 180);
    // Draw the image centered (it will be scaled to the target dimensions)
    ctx.drawImage(img, -targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight);
    ctx.restore();
  }

  // ======= LOAD IMAGES =======
  fileInput.addEventListener('change', function(e) {
    const files = e.target.files;
    if (!files.length) return;

    images = [];
    thumbnailsDiv.innerHTML = '';
    
    Array.from(files).forEach((file, index) => {
      const reader = new FileReader();
      reader.onload = function(event) {
        const img = new Image();
        img.onload = function() {
          // Store image and default rotation (0°)
          images.push({ img: img, rotation: 0 });

          // Create a thumbnail canvas for this image
          const thumbCanvas = document.createElement('canvas');
          thumbCanvas.width = 80;
          thumbCanvas.height = 80;
          const tctx = thumbCanvas.getContext('2d');
          tctx.drawImage(img, 0, 0, thumbCanvas.width, thumbCanvas.height);
          thumbCanvas.style.cursor = 'pointer';
          // On click, set this image as the current image and update resize fields
          thumbCanvas.addEventListener('click', function() {
            currentIndex = index;
            widthInput.value = img.width;
            heightInput.value = img.height;
            drawImage();
          });
          thumbnailsDiv.appendChild(thumbCanvas);

          // Automatically load the first image
          if (index === 0) {
            currentIndex = 0;
            widthInput.value = img.width;
            heightInput.value = img.height;
            drawImage();
          }
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    });
  });

  // ======= RESIZE BUTTON =======
  resizeButton.addEventListener('click', function() {
    drawImage();
  });

  // ======= ROTATION BUTTONS =======
  rotateLeftButton.addEventListener('click', function() {
    if (images.length === 0) return;
    images[currentIndex].rotation -= 90;
    drawImage();
  });

  rotateRightButton.addEventListener('click', function() {
    if (images.length === 0) return;
    images[currentIndex].rotation += 90;
    drawImage();
  });

  // ======= CROP BUTTON =======
  // This crop uses a simple center crop method.
  cropButton.addEventListener('click', function() {
    if (images.length === 0) return;
    // Use provided crop dimensions; default to current canvas size if not entered.
    const cropWidth = parseInt(cropWidthInput.value, 10) || canvas.width;
    const cropHeight = parseInt(cropHeightInput.value, 10) || canvas.height;
    
    // Create a temporary canvas for cropping
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = cropWidth;
    tempCanvas.height = cropHeight;
    const tempCtx = tempCanvas.getContext('2d');

    // Calculate coordinates for a center crop
    const startX = (canvas.width - cropWidth) / 2;
    const startY = (canvas.height - cropHeight) / 2;

    // Draw the cropped portion from the current canvas onto the temporary canvas
    tempCtx.drawImage(canvas, startX, startY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);

    // Update the main canvas with the cropped image
    canvas.width = cropWidth;
    canvas.height = cropHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(tempCanvas, 0, 0);

    // Update the resize inputs with new dimensions
    widthInput.value = cropWidth;
    heightInput.value = cropHeight;

    // Update the current image with the cropped result
    const croppedImg = new Image();
    croppedImg.onload = function() {
      images[currentIndex].img = croppedImg;
      images[currentIndex].rotation = 0; // Reset rotation after cropping
      drawImage();
    };
    croppedImg.src = canvas.toDataURL('image/jpeg');
  });

  // ======= DOWNLOAD FUNCTIONALITY =======
  // Clicking the canvas creates a download link.
  canvas.addEventListener('click', function() {
    const dataURL = canvas.toDataURL('image/jpeg');
    const downloadLink = document.createElement('a');
    downloadLink.href = dataURL;
    downloadLink.download = 'edited-image.jpg';
    downloadLink.textContent = 'Download Edited Image';
    downloadArea.innerHTML = '';
    downloadArea.appendChild(downloadLink);
  });
});
